#include <iostream>
using namespace std;

int main() {
  
  int num = 7;

  if(num%2 == 0) {
    cout << "Even" << endl;
  }
  else {
    cout << "Odd" << endl;
  }




//   int num = 0;

//   if(num > 0) {
//     cout << "Positive " << endl;
//   }
//   else if(num < 0) {
//     cout << "negative" << endl;
//   }
//   else {
//     cout << "zero" << endl;
//   }
  
  return 0;
}