#include<iostream>
using namespace std;

int main() {
	int i=1;
	for(; ; ) {
		cout << "value of i is :" << i << endl;
		if(i<5) {
			cout << "babbar" << endl;
			i=i+1;
		}
		else {
			break;
		}
		
	}

	cout << "Hi" << endl;

	
	// for(int i=0; i<3; i=i+1) {
	// 	cout<< endl << "Outer Loop " << i << endl << endl; 
		
	// 	for(int j=0; j<3; j=j+1) {
	// 		cout << "inner loop " << j << endl;
	// 	}
		
	// }
	
	// for(int i=0; i<5; i=i+1) {
	// 	cout << "A" << " ";
	// }
	// cout << endl;
	
	// for(int i=10 ;i>=0; i= i - 3) {
	// 	cout << i << endl;
	// }
	
	// for(int i=2; i<10; i=i+2) {
	// 	cout << i << endl;
	// }

	// for(int i=10; i<=12; i=i+1) {
	// 	cout << "Monica, my darlo" << endl;
	// }

	
	// int num = 8;
	
	//   if(num%2 == 0) {
	//     cout << "Even" << endl;
	//   }
	//   else {
	//     cout << "Odd" << endl;
	//   }
	// int marks;

	// cout << "Enter the marks here: " << endl;
	// //take input from user
	// cin >> marks;

	// cout << "Printing marks: " << marks << endl;
	

	// int age = 101;
	// int car = 12;
	
	// if(age >= 18 || car >=1) {
	// 	cout << "License miljaega" << endl;
	// }

	// cout << !age << endl;
	
	// int a = 20;
	// int b = 10;

	// cout << (a == b) << endl;
		
	// int a = 3;
	// int b = 2;

	// cout << a + b << endl;
	// cout << a - b << endl;
	// cout << a*b << endl;
	//cout << a/b << endl;
	//cout << b % a << endl; 
	//garbage value
	// int num;
	// num = 12;
	// cout << num << endl;

	//int -> 4 byte
	// int num = 50;
	// cout << num << endl;

	// cout << sizeof(num) << endl;

	// //character -> 1byte
	// char ch = 'k';
	// cout << ch << endl;
	// cout << sizeof(ch) << endl;

	// //float -> 4 byte
	// float point = 1.69;
	// cout << point << endl;
	// cout << sizeof(point) << endl;

	// //long -> 4 byte
	// long number = 23;
	// cout << number << endl;
	// cout << sizeof(number) << endl;
	
	// cout << "Love " << endl << "babbar" << '\n';
	// cout << "Love Babbar" << endl ;
	// cout << endl;
	// cout << endl;
	// cout << '\n';
	// cout << "Lovely Babbar" ;

	//find in homework
	return 0;
}